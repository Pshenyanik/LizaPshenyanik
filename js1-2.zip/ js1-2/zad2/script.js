
var arr=[];
for (var i = 0; i < 5; i++) {
    arr.push( prompt('Введите имя', ''));
}

var x = prompt('Введите имя пользователя', '');


for(var i = 0; i < 5; i++)
{
    if ( x == arr[i]) 
    {
      alert( x + ' вы успешно вошли' );
      var flag = true;
    } 
}
 if (flag !== true) {
     alert( 'Веденное имя пользователя не существует в массиве!' ); 
    }


