function pow(x, n) {
   var result = 1; 
if(n > 0) 
{
   for (var i=0; i < n; i++) {
       result *=x;
     }

    return result;
}  else 
{
    if(n < 0)
     {
   for (var i=0; n < i; n++) {
       result /=x;
     }

    return result;
   
}  else 
{
    if(n = 0)
     {
      result = 1;
   }
   return result;
}
}
}
var x = prompt('Введите число', '');
var n = prompt('Введите степень', '');


    alert ( pow(x, n) );


//var myVariable = 5;
//alert(myVariable);